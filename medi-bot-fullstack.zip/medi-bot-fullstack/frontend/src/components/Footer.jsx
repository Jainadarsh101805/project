import React from 'react';
export default function Footer(){ return <footer>© {new Date().getFullYear()} MediBot — Demo</footer>; }
