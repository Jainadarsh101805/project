# Apple-Plant-Disease-Detection-with-AI
Designing and developing an AI model which detects diseased apple plant by image scanning of apple plant leaves. 
